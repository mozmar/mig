#!/bin/sh
for f in "/etc/cron.d/mig-agent" "/etc/init/mig-agent.conf" "/etc/init.d/mig-agent" "/etc/systemd/system/mig-agent.service"; do
    [ -e "$f" ] && rm -f "$f"
done
echo mig-agent removed but not killed if running
