#!/bin/sh
chmod 500 /sbin/mig-agent-20180803-0.e8eb90a.prod
chown root:root /sbin/mig-agent-20180803-0.e8eb90a.prod
rm /sbin/mig-agent; ln -s /sbin/mig-agent-20180803-0.e8eb90a.prod /sbin/mig-agent
